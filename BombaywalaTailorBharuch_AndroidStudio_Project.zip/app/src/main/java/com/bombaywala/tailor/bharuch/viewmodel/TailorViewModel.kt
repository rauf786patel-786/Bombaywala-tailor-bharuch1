package com.bombaywala.tailor.bharuch.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bombaywala.tailor.bharuch.data.database.TailorDatabase
import com.bombaywala.tailor.bharuch.data.model.Customer
import com.bombaywala.tailor.bharuch.data.model.MeasurementRecord
import com.bombaywala.tailor.bharuch.data.repository.TailorRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TailorViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: TailorRepository
    val searchQuery = MutableStateFlow("")

    val customers: StateFlow<List<Customer>> = searchQuery
        .debounce(250)
        .flatMapLatest { query ->
            repository.searchCustomers(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        val db = TailorDatabase.getDatabase(application)
        repository = TailorRepository(db.customerDao(), db.measurementDao())
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun saveCustomer(name: String, mobile: String, address: String, notes: String, existingId: Long = 0, onSaved: (Long) -> Unit) {
        viewModelScope.launch {
            val customer = Customer(
                id = existingId,
                name = name.trim(),
                mobileNumber = mobile.trim(),
                address = address.trim(),
                notes = notes.trim(),
                updatedAt = System.currentTimeMillis()
            )
            val id = if (existingId == 0L) {
                repository.insertCustomer(customer)
            } else {
                repository.updateCustomer(customer)
                existingId
            }
            onSaved(id)
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    fun getMeasurementsForCustomer(customerId: Long): Flow<List<MeasurementRecord>> {
        return repository.getMeasurementsForCustomer(customerId)
    }

    fun saveMeasurement(record: MeasurementRecord, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            if (record.id == 0L) {
                repository.insertMeasurement(record)
            } else {
                repository.updateMeasurement(record)
            }
            onComplete()
        }
    }

    fun deleteMeasurement(record: MeasurementRecord) {
        viewModelScope.launch {
            repository.deleteMeasurement(record)
        }
    }
}
